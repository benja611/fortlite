# ⚡ Storm Arena 2D

**Battle Royale 2D** inspirado en Fortnite, hecho para jugar con amigos y que **funcione en el colegio**.

## 🎮 Características

- Vista cenital (top-down)
- Zona que se cierra (la tormenta)
- Disparos, vida y eliminaciones
- Recoges munición y curaciones
- **Modo 1 jugador** vs bots
- **Modo 2 jugadores local** (mismo teclado) → perfecto para jugar con un amigo
- 100% offline (no necesita internet ni servidores)
- No se puede bloquear fácilmente porque son solo archivos HTML

## 🕹️ Controles

| Acción              | Jugador 1          | Jugador 2              |
|---------------------|--------------------|------------------------|
| Moverse             | **WASD**           | **Flechas**            |
| Apuntar             | **Ratón**          | Dirección del movimiento |
| Disparar            | **Click izquierdo**| **Shift** o Click derecho |

## 🚀 Cómo usarlo en el colegio

### Opción A – Más fácil (recomendada)
1. Descarga la carpeta completa
2. Abre el archivo `index.html` con Chrome o Edge
3. ¡A jugar! (funciona sin internet)

### Opción B – Subirlo a GitHub Pages
1. Crea un repositorio en GitHub
2. Sube todos los archivos
3. Activa **GitHub Pages**
4. Comparte el enlace con tus amigos (pueden jugar en sus móviles/PC)

```bash
git init
git add .
git commit -m "⚡ Storm Arena 2D"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/storm-arena.git
git push -u origin main
```

## 📁 Archivos

```
storm-arena/
├── index.html
├── style.css
├── game.js
└── README.md
```

## 💡 Notas

- El modo **2 jugadores local** es el ideal para el colegio (no necesita red).
- Si quieres jugar online de verdad con más amigos, se puede ampliar más adelante con un servidor simple.

¡Que gane el mejor!
