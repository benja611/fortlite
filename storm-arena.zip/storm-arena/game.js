(() => {
  // ========== CONFIG ==========
  const WORLD = 2400;          // tamaño del mapa
  const PLAYER_SPEED = 220;
  const BOT_SPEED = 160;
  const BULLET_SPEED = 520;
  const FIRE_RATE = 180;       // ms
  const ZONE_DAMAGE = 8;       // daño por segundo fuera de la zona
  const START_RADIUS = 1100;
  const FINAL_RADIUS = 180;

  // ========== DOM ==========
  const menu = document.getElementById('menu');
  const gameScreen = document.getElementById('game');
  const gameover = document.getElementById('gameover');
  const canvas = document.getElementById('canvas');
  const ctx = canvas.getContext('2d');
  const messageEl = document.getElementById('message');
  const goTitle = document.getElementById('goTitle');
  const goSubtitle = document.getElementById('goSubtitle');

  // ========== STATE ==========
  let mode = 'solo'; // solo | duo
  let players = [];
  let bots = [];
  let bullets = [];
  let particles = [];
  let pickups = [];
  let keys = {};
  let mouse = { x: 0, y: 0, down: false, right: false };
  let camera = { x: 0, y: 0 };
  let zone = { x: WORLD / 2, y: WORLD / 2, r: START_RADIUS, targetR: START_RADIUS, timer: 25 };
  let aliveCount = 0;
  let running = false;
  let lastTime = 0;
  let winner = null;

  // ========== UTILS ==========
  function rand(min, max) {
    return Math.random() * (max - min) + min;
  }

  function dist(a, b) {
    return Math.hypot(a.x - b.x, a.y - b.y);
  }

  function angle(a, b) {
    return Math.atan2(b.y - a.y, b.x - a.x);
  }

  function clamp(v, min, max) {
    return Math.max(min, Math.min(max, v));
  }

  // ========== ENTITIES ==========
  function createPlayer(id, x, y, color, controls) {
    return {
      id,
      x, y,
      vx: 0, vy: 0,
      radius: 16,
      hp: 100,
      maxHp: 100,
      color,
      controls, // 'wasd' | 'arrows'
      angle: 0,
      ammo: 30,
      maxAmmo: 30,
      lastShot: 0,
      alive: true,
      kills: 0,
      invuln: 0
    };
  }

  function createBot(x, y) {
    return {
      id: 'bot_' + Math.random().toString(36).slice(2, 7),
      x, y,
      vx: 0, vy: 0,
      radius: 15,
      hp: 70,
      maxHp: 70,
      color: `hsl(${rand(0, 360)}, 70%, 55%)`,
      angle: 0,
      ammo: 20,
      lastShot: 0,
      alive: true,
      target: null,
      changeDir: 0,
      isBot: true
    };
  }

  function createBullet(owner, ang) {
    return {
      x: owner.x + Math.cos(ang) * 22,
      y: owner.y + Math.sin(ang) * 22,
      vx: Math.cos(ang) * BULLET_SPEED,
      vy: Math.sin(ang) * BULLET_SPEED,
      owner: owner.id,
      life: 1.4,
      damage: 18
    };
  }

  function spawnPickup(x, y) {
    pickups.push({
      x, y,
      type: Math.random() < 0.6 ? 'ammo' : 'health',
      life: 18
    });
  }

  // ========== INIT ==========
  function startGame(selectedMode) {
    mode = selectedMode;
    players = [];
    bots = [];
    bullets = [];
    particles = [];
    pickups = [];
    winner = null;
    zone = { x: WORLD / 2, y: WORLD / 2, r: START_RADIUS, targetR: START_RADIUS, timer: 22 };

    // Spawn players near center but apart
    const cx = WORLD / 2;
    const cy = WORLD / 2;

    players.push(createPlayer(1, cx - 80, cy, '#00e5ff', 'wasd'));

    if (mode === 'duo') {
      players.push(createPlayer(2, cx + 80, cy, '#ff2d55', 'arrows'));
      document.getElementById('hud2').style.display = 'block';
    } else {
      document.getElementById('hud2').style.display = 'none';
    }

    // Spawn bots
    const botCount = mode === 'solo' ? 12 : 10;
    for (let i = 0; i < botCount; i++) {
      let bx, by, tries = 0;
      do {
        bx = rand(150, WORLD - 150);
        by = rand(150, WORLD - 150);
        tries++;
      } while (dist({ x: bx, y: by }, { x: cx, y: cy }) < 220 && tries < 30);
      bots.push(createBot(bx, by));
    }

    // Some starting pickups
    for (let i = 0; i < 18; i++) {
      spawnPickup(rand(200, WORLD - 200), rand(200, WORLD - 200));
    }

    updateAlive();
    menu.classList.add('hidden');
    gameover.classList.add('hidden');
    gameScreen.classList.remove('hidden');
    running = true;
    lastTime = performance.now();
    requestAnimationFrame(loop);

    showMessage('¡La batalla comienza!', 1.6);
  }

  function updateAlive() {
    aliveCount = players.filter(p => p.alive).length + bots.filter(b => b.alive).length;
    document.getElementById('aliveCount').textContent = aliveCount;
  }

  // ========== INPUT ==========
  window.addEventListener('keydown', e => {
    keys[e.code] = true;
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
      e.preventDefault();
    }
  });
  window.addEventListener('keyup', e => { keys[e.code] = false; });

  canvas.addEventListener('mousemove', e => {
    const rect = canvas.getBoundingClientRect();
    mouse.x = (e.clientX - rect.left) * (canvas.width / rect.width);
    mouse.y = (e.clientY - rect.top) * (canvas.height / rect.height);
  });
  canvas.addEventListener('mousedown', e => {
    if (e.button === 0) mouse.down = true;
    if (e.button === 2) mouse.right = true;
  });
  canvas.addEventListener('mouseup', e => {
    if (e.button === 0) mouse.down = false;
    if (e.button === 2) mouse.right = false;
  });
  canvas.addEventListener('contextmenu', e => e.preventDefault());

  // Touch support (simple)
  let touchId = null;
  canvas.addEventListener('touchstart', e => {
    e.preventDefault();
    const t = e.changedTouches[0];
    touchId = t.identifier;
    const rect = canvas.getBoundingClientRect();
    mouse.x = (t.clientX - rect.left) * (canvas.width / rect.width);
    mouse.y = (t.clientY - rect.top) * (canvas.height / rect.height);
    mouse.down = true;
  }, { passive: false });
  canvas.addEventListener('touchmove', e => {
    e.preventDefault();
    for (const t of e.changedTouches) {
      if (t.identifier === touchId) {
        const rect = canvas.getBoundingClientRect();
        mouse.x = (t.clientX - rect.left) * (canvas.width / rect.width);
        mouse.y = (t.clientY - rect.top) * (canvas.height / rect.height);
      }
    }
  }, { passive: false });
  canvas.addEventListener('touchend', e => {
    mouse.down = false;
    touchId = null;
  });

  // ========== UPDATE ==========
  function update(dt) {
    // Zone shrink
    zone.timer -= dt;
    if (zone.timer <= 0) {
      zone.targetR = Math.max(FINAL_RADIUS, zone.targetR * 0.72);
      zone.timer = 18 + Math.random() * 6;
      showMessage('¡La zona se cierra!', 1.4);
    }
    zone.r += (zone.targetR - zone.r) * Math.min(1, dt * 0.35);

    // Players
    players.forEach(p => {
      if (!p.alive) return;
      p.invuln = Math.max(0, p.invuln - dt);

      // Movement
      let mx = 0, my = 0;
      if (p.controls === 'wasd') {
        if (keys['KeyW'] || keys['ArrowUp'] && mode === 'solo') my -= 1;
        if (keys['KeyS']) my += 1;
        if (keys['KeyA']) mx -= 1;
        if (keys['KeyD']) mx += 1;
        // In solo also allow arrows for convenience
        if (mode === 'solo') {
          if (keys['ArrowUp']) my -= 1;
          if (keys['ArrowDown']) my += 1;
          if (keys['ArrowLeft']) mx -= 1;
          if (keys['ArrowRight']) mx += 1;
        }
      } else {
        if (keys['ArrowUp']) my -= 1;
        if (keys['ArrowDown']) my += 1;
        if (keys['ArrowLeft']) mx -= 1;
        if (keys['ArrowRight']) mx += 1;
      }

      if (mx || my) {
        const len = Math.hypot(mx, my);
        p.vx = (mx / len) * PLAYER_SPEED;
        p.vy = (my / len) * PLAYER_SPEED;
      } else {
        p.vx *= 0.85;
        p.vy *= 0.85;
      }

      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.x = clamp(p.x, p.radius, WORLD - p.radius);
      p.y = clamp(p.y, p.radius, WORLD - p.radius);

      // Aim
      if (p.controls === 'wasd') {
        const worldMouse = {
          x: mouse.x + camera.x,
          y: mouse.y + camera.y
        };
        p.angle = angle(p, worldMouse);
      } else {
        // Player 2 aims in movement direction or last direction
        if (Math.hypot(p.vx, p.vy) > 10) {
          p.angle = Math.atan2(p.vy, p.vx);
        }
      }

      // Shoot
      const canShoot = (p.controls === 'wasd' && mouse.down) ||
                       (p.controls === 'arrows' && (keys['ShiftLeft'] || keys['ShiftRight'] || mouse.right));

      if (canShoot && p.ammo > 0 && performance.now() - p.lastShot > FIRE_RATE) {
        bullets.push(createBullet(p, p.angle));
        p.ammo--;
        p.lastShot = performance.now();
        // muzzle flash particle
        particles.push({
          x: p.x + Math.cos(p.angle) * 20,
          y: p.y + Math.sin(p.angle) * 20,
          vx: Math.cos(p.angle) * 40,
          vy: Math.sin(p.angle) * 40,
          life: 0.15,
          color: '#fff',
          size: 4
        });
      }

      // Zone damage
      if (dist(p, zone) > zone.r) {
        p.hp -= ZONE_DAMAGE * dt;
        if (p.hp <= 0) kill(p, null);
      }

      // Pickups
      pickups.forEach((pk, i) => {
        if (dist(p, pk) < p.radius + 14) {
          if (pk.type === 'ammo') {
            p.ammo = Math.min(p.maxAmmo, p.ammo + 15);
          } else {
            p.hp = Math.min(p.maxHp, p.hp + 35);
          }
          pickups.splice(i, 1);
        }
      });
    });

    // Bots AI (simple)
    bots.forEach(b => {
      if (!b.alive) return;

      b.changeDir -= dt;
      if (b.changeDir <= 0 || !b.target) {
        // Find nearest alive player or random
        let nearest = null;
        let nearestD = 9999;
        [...players, ...bots].forEach(other => {
          if (other === b || !other.alive) return;
          const d = dist(b, other);
          if (d < nearestD) {
            nearestD = d;
            nearest = other;
          }
        });
        b.target = nearest;
        b.changeDir = rand(0.6, 1.8);
      }

      if (b.target && b.target.alive) {
        const d = dist(b, b.target);
        const a = angle(b, b.target);

        // Move toward or strafe
        if (d > 280) {
          b.vx = Math.cos(a) * BOT_SPEED;
          b.vy = Math.sin(a) * BOT_SPEED;
        } else if (d < 140) {
          b.vx = -Math.cos(a) * BOT_SPEED * 0.7;
          b.vy = -Math.sin(a) * BOT_SPEED * 0.7;
        } else {
          // circle a bit
          b.vx = Math.cos(a + 1.2) * BOT_SPEED * 0.6;
          b.vy = Math.sin(a + 1.2) * BOT_SPEED * 0.6;
        }

        b.angle = a;

        // Shoot if close enough
        if (d < 420 && b.ammo > 0 && performance.now() - b.lastShot > 420 + Math.random() * 200) {
          // slight inaccuracy
          const spread = (Math.random() - 0.5) * 0.25;
          bullets.push(createBullet(b, a + spread));
          b.ammo--;
          b.lastShot = performance.now();
        }
      }

      b.x += b.vx * dt;
      b.y += b.vy * dt;
      b.x = clamp(b.x, b.radius, WORLD - b.radius);
      b.y = clamp(b.y, b.radius, WORLD - b.radius);

      // Zone damage for bots
      if (dist(b, zone) > zone.r) {
        b.hp -= ZONE_DAMAGE * 1.3 * dt;
        if (b.hp <= 0) kill(b, null);
      }
    });

    // Bullets
    for (let i = bullets.length - 1; i >= 0; i--) {
      const bl = bullets[i];
      bl.x += bl.vx * dt;
      bl.y += bl.vy * dt;
      bl.life -= dt;

      if (bl.life <= 0 || bl.x < 0 || bl.x > WORLD || bl.y < 0 || bl.y > WORLD) {
        bullets.splice(i, 1);
        continue;
      }

      // Hit check
      const targets = [...players, ...bots];
      for (const t of targets) {
        if (!t.alive || t.id === bl.owner) continue;
        if (dist(bl, t) < t.radius + 4) {
          if (t.invuln > 0) continue;
          t.hp -= bl.damage;
          // blood particles
          for (let k = 0; k < 6; k++) {
            particles.push({
              x: t.x,
              y: t.y,
              vx: rand(-80, 80),
              vy: rand(-80, 80),
              life: rand(0.3, 0.7),
              color: '#ff2d55',
              size: rand(2, 5)
            });
          }
          bullets.splice(i, 1);
          if (t.hp <= 0) {
            const killer = players.find(p => p.id === bl.owner) || bots.find(b => b.id === bl.owner);
            kill(t, killer);
          }
          break;
        }
      }
    }

    // Particles
    for (let i = particles.length - 1; i >= 0; i--) {
      const pt = particles[i];
      pt.x += pt.vx * dt;
      pt.y += pt.vy * dt;
      pt.life -= dt;
      pt.vx *= 0.96;
      pt.vy *= 0.96;
      if (pt.life <= 0) particles.splice(i, 1);
    }

    // Pickups life
    for (let i = pickups.length - 1; i >= 0; i--) {
      pickups[i].life -= dt;
      if (pickups[i].life <= 0) pickups.splice(i, 1);
    }

    // Camera (follow player 1 mostly, or midpoint in duo)
    if (players[0] && players[0].alive) {
      camera.x = players[0].x - canvas.width / 2;
      camera.y = players[0].y - canvas.height / 2;
    } else if (players[1] && players[1].alive) {
      camera.x = players[1].x - canvas.width / 2;
      camera.y = players[1].y - canvas.height / 2;
    }
    camera.x = clamp(camera.x, 0, WORLD - canvas.width);
    camera.y = clamp(camera.y, 0, WORLD - canvas.height);

    // HUD
    updateHUD();

    // Win condition
    const alivePlayers = players.filter(p => p.alive);
    const aliveBots = bots.filter(b => b.alive);
    if (alivePlayers.length + aliveBots.length <= 1) {
      endGame(alivePlayers[0] || null);
    }
  }

  function kill(entity, killer) {
    entity.alive = false;
    entity.hp = 0;
    if (killer && killer.kills !== undefined) killer.kills++;
    // death particles
    for (let i = 0; i < 14; i++) {
      particles.push({
        x: entity.x,
        y: entity.y,
        vx: rand(-120, 120),
        vy: rand(-120, 120),
        life: rand(0.4, 0.9),
        color: entity.color,
        size: rand(3, 7)
      });
    }
    // chance to drop loot
    if (Math.random() < 0.7) spawnPickup(entity.x, entity.y);
    updateAlive();
  }

  function updateHUD() {
    players.forEach((p, i) => {
      const hpEl = document.getElementById('hp' + (i + 1));
      const ammoEl = document.getElementById('ammo' + (i + 1));
      if (hpEl) {
        hpEl.style.width = Math.max(0, (p.hp / p.maxHp) * 100) + '%';
        hpEl.style.background = p.hp < 30
          ? 'linear-gradient(90deg, #ff2d55, #ff6b6b)'
          : 'linear-gradient(90deg, #00ff9d, #00e5ff)';
      }
      if (ammoEl) ammoEl.textContent = p.alive ? p.ammo : '—';
    });
    document.getElementById('zoneTime').textContent = Math.ceil(zone.timer) + 's';
  }

  function showMessage(text, duration = 1.5) {
    messageEl.textContent = text;
    messageEl.classList.remove('hidden');
    clearTimeout(messageEl._t);
    messageEl._t = setTimeout(() => messageEl.classList.add('hidden'), duration * 1000);
  }

  function endGame(winnerPlayer) {
    running = false;
    gameScreen.classList.add('hidden');
    gameover.classList.remove('hidden');

    if (winnerPlayer) {
      goTitle.textContent = mode === 'duo'
        ? `¡Ganó el Jugador ${winnerPlayer.id}!`
        : '¡Victoria Royale!';
      goSubtitle.textContent = `Eliminaciones: ${winnerPlayer.kills || 0}`;
    } else {
      goTitle.textContent = 'Todos eliminados';
      goSubtitle.textContent = 'La tormenta lo consumió todo';
    }
  }

  // ========== RENDER ==========
  function draw() {
    ctx.save();
    ctx.translate(-camera.x, -camera.y);

    // Background grid
    ctx.fillStyle = '#0d1525';
    ctx.fillRect(0, 0, WORLD, WORLD);

    ctx.strokeStyle = 'rgba(0, 229, 255, 0.04)';
    ctx.lineWidth = 1;
    for (let x = 0; x <= WORLD; x += 80) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, WORLD);
      ctx.stroke();
    }
    for (let y = 0; y <= WORLD; y += 80) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(WORLD, y);
      ctx.stroke();
    }

    // Zone (safe area circle + dangerous outside)
    // Darken outside
    ctx.fillStyle = 'rgba(255, 45, 85, 0.18)';
    ctx.beginPath();
    ctx.rect(0, 0, WORLD, WORLD);
    ctx.arc(zone.x, zone.y, zone.r, 0, Math.PI * 2, true);
    ctx.fill('evenodd');

    // Zone border
    ctx.strokeStyle = 'rgba(0, 229, 255, 0.7)';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(zone.x, zone.y, zone.r, 0, Math.PI * 2);
    ctx.stroke();

    // Inner glow
    ctx.strokeStyle = 'rgba(0, 229, 255, 0.15)';
    ctx.lineWidth = 18;
    ctx.beginPath();
    ctx.arc(zone.x, zone.y, zone.r, 0, Math.PI * 2);
    ctx.stroke();

    // Pickups
    pickups.forEach(pk => {
      ctx.beginPath();
      ctx.arc(pk.x, pk.y, 10, 0, Math.PI * 2);
      ctx.fillStyle = pk.type === 'ammo' ? '#ffd60a' : '#00ff9d';
      ctx.fill();
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = 2;
      ctx.stroke();
    });

    // Bullets
    bullets.forEach(bl => {
      ctx.beginPath();
      ctx.arc(bl.x, bl.y, 4, 0, Math.PI * 2);
      ctx.fillStyle = '#fff';
      ctx.fill();
      ctx.beginPath();
      ctx.arc(bl.x, bl.y, 7, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(0, 229, 255, 0.35)';
      ctx.fill();
    });

    // Particles
    particles.forEach(pt => {
      ctx.globalAlpha = Math.max(0, pt.life * 2);
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, pt.size, 0, Math.PI * 2);
      ctx.fillStyle = pt.color;
      ctx.fill();
      ctx.globalAlpha = 1;
    });

    // Bots
    bots.forEach(b => {
      if (!b.alive) return;
      drawCharacter(b, false);
    });

    // Players
    players.forEach(p => {
      if (!p.alive) return;
      drawCharacter(p, true);
    });

    ctx.restore();
  }

  function drawCharacter(ent, isPlayer) {
    // Body
    ctx.beginPath();
    ctx.arc(ent.x, ent.y, ent.radius, 0, Math.PI * 2);
    ctx.fillStyle = ent.color;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.35)';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Direction indicator (gun)
    ctx.beginPath();
    ctx.moveTo(ent.x, ent.y);
    ctx.lineTo(
      ent.x + Math.cos(ent.angle) * (ent.radius + 14),
      ent.y + Math.sin(ent.angle) * (ent.radius + 14)
    );
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 4;
    ctx.lineCap = 'round';
    ctx.stroke();

    // Health bar
    if (ent.hp < ent.maxHp) {
      const bw = 34;
      const bh = 5;
      ctx.fillStyle = 'rgba(0,0,0,0.5)';
      ctx.fillRect(ent.x - bw / 2, ent.y - ent.radius - 12, bw, bh);
      ctx.fillStyle = ent.hp < 30 ? '#ff2d55' : '#00ff9d';
      ctx.fillRect(ent.x - bw / 2, ent.y - ent.radius - 12, bw * (ent.hp / ent.maxHp), bh);
    }

    // Name
    if (isPlayer) {
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 11px system-ui';
      ctx.textAlign = 'center';
      ctx.fillText('J' + ent.id, ent.x, ent.y - ent.radius - 18);
    }
  }

  // ========== LOOP ==========
  function loop(timestamp) {
    if (!running) return;
    const dt = Math.min(0.05, (timestamp - lastTime) / 1000);
    lastTime = timestamp;

    update(dt);
    draw();

    requestAnimationFrame(loop);
  }

  // ========== RESIZE ==========
  function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  window.addEventListener('resize', resize);
  resize();

  // ========== BUTTONS ==========
  document.querySelectorAll('[data-mode]').forEach(btn => {
    btn.addEventListener('click', () => {
      startGame(btn.dataset.mode);
    });
  });

  document.getElementById('restartBtn').addEventListener('click', () => {
    startGame(mode);
  });

  document.getElementById('menuBtn').addEventListener('click', () => {
    gameover.classList.add('hidden');
    menu.classList.remove('hidden');
  });
})();
